import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Bell,
  Bookmark,
  Camera,
  Heart,
  Home,
  Image,
  MessageCircle,
  MoreHorizontal,
  Search,
  Send,
  Share2,
  Sparkles,
  UserRound,
  Users,
} from 'lucide-react';
import './styles.css';

const initialPosts = [
  {
    id: 1,
    author: 'Maya Chen',
    handle: '@maya',
    avatar: 'MC',
    time: '12m',
    body: 'Launched a tiny habit tracker this morning. Three screens, one clear promise, zero clutter.',
    image:
      'https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1200&q=80',
    likes: 128,
    comments: 18,
    color: '#0f766e',
  },
  {
    id: 2,
    author: 'Noah Reed',
    handle: '@noahre',
    avatar: 'NR',
    time: '31m',
    body: 'Design note: empty states should feel like a helpful pause, not a dead end.',
    likes: 84,
    comments: 11,
    color: '#9a3412',
  },
  {
    id: 3,
    author: 'Ari Shah',
    handle: '@arishah',
    avatar: 'AS',
    time: '1h',
    body: 'Who else is building in public this week? Drop your project and I will follow along.',
    image:
      'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80',
    likes: 206,
    comments: 42,
    color: '#1d4ed8',
  },
];

const suggestions = [
  ['Elena Park', '@elenap', 'EP'],
  ['Jon Bell', '@jonbuilds', 'JB'],
  ['Priya Rao', '@priya', 'PR'],
];

function App() {
  const [posts, setPosts] = useState(initialPosts);
  const [draft, setDraft] = useState('');
  const [activeTab, setActiveTab] = useState('home');
  const [query, setQuery] = useState('');

  const filteredPosts = useMemo(() => {
    const clean = query.trim().toLowerCase();
    if (!clean) return posts;
    return posts.filter(
      (post) =>
        post.body.toLowerCase().includes(clean) ||
        post.author.toLowerCase().includes(clean) ||
        post.handle.toLowerCase().includes(clean),
    );
  }, [posts, query]);

  function publishPost() {
    const body = draft.trim();
    if (!body) return;

    setPosts([
      {
        id: Date.now(),
        author: 'Aditya',
        handle: '@aditya',
        avatar: 'A',
        time: 'now',
        body,
        likes: 0,
        comments: 0,
        color: '#be123c',
      },
      ...posts,
    ]);
    setDraft('');
  }

  function toggleLike(id) {
    setPosts((current) =>
      current.map((post) =>
        post.id === id
          ? {
              ...post,
              liked: !post.liked,
              likes: post.liked ? post.likes - 1 : post.likes + 1,
            }
          : post,
      ),
    );
  }

  return (
    <div className="app-shell">
      <aside className="sidebar" aria-label="Main navigation">
        <div className="brand">
          <span className="brand-mark">
            <Sparkles size={22} />
          </span>
          <span>Pulse</span>
        </div>

        <nav className="nav-list">
          {[
            ['home', Home, 'Home'],
            ['discover', Search, 'Discover'],
            ['circles', Users, 'Circles'],
            ['saved', Bookmark, 'Saved'],
            ['profile', UserRound, 'Profile'],
          ].map(([key, Icon, label]) => (
            <button
              className={activeTab === key ? 'nav-item active' : 'nav-item'}
              key={key}
              onClick={() => setActiveTab(key)}
            >
              <Icon size={20} />
              <span>{label}</span>
            </button>
          ))}
        </nav>

        <button className="compose-button" onClick={() => document.getElementById('composer')?.focus()}>
          <Send size={18} />
          <span>Post</span>
        </button>
      </aside>

      <main className="feed-column">
        <header className="topbar">
          <div>
            <p className="eyebrow">Good afternoon</p>
            <h1>Home feed</h1>
          </div>
          <button className="icon-button" aria-label="Notifications">
            <Bell size={21} />
          </button>
        </header>

        <section className="composer" aria-label="Create a post">
          <div className="avatar self">A</div>
          <div className="composer-body">
            <textarea
              id="composer"
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              placeholder="What are you working on?"
              maxLength={220}
            />
            <div className="composer-actions">
              <div className="tool-row">
                <button className="icon-button small" aria-label="Add image">
                  <Image size={18} />
                </button>
                <button className="icon-button small" aria-label="Open camera">
                  <Camera size={18} />
                </button>
                <span>{220 - draft.length}</span>
              </div>
              <button className="primary-button" onClick={publishPost} disabled={!draft.trim()}>
                <Send size={17} />
                <span>Publish</span>
              </button>
            </div>
          </div>
        </section>

        <section className="posts" aria-label="Posts">
          {filteredPosts.map((post) => (
            <article className="post-card" key={post.id}>
              <div className="post-header">
                <div className="avatar" style={{ background: post.color }}>
                  {post.avatar}
                </div>
                <div className="post-author">
                  <strong>{post.author}</strong>
                  <span>
                    {post.handle} · {post.time}
                  </span>
                </div>
                <button className="icon-button small" aria-label="More options">
                  <MoreHorizontal size={18} />
                </button>
              </div>

              <p className="post-body">{post.body}</p>
              {post.image && <img className="post-image" src={post.image} alt="" />}

              <div className="post-actions">
                <button className={post.liked ? 'action liked' : 'action'} onClick={() => toggleLike(post.id)}>
                  <Heart size={18} fill={post.liked ? 'currentColor' : 'none'} />
                  <span>{post.likes}</span>
                </button>
                <button className="action">
                  <MessageCircle size={18} />
                  <span>{post.comments}</span>
                </button>
                <button className="action">
                  <Share2 size={18} />
                  <span>Share</span>
                </button>
              </div>
            </article>
          ))}
        </section>
      </main>

      <aside className="right-panel">
        <label className="search-box">
          <Search size={18} />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search Pulse"
          />
        </label>

        <section className="panel-block">
          <h2>Trending</h2>
          {['#buildinpublic', '#uxwriting', '#productdesign'].map((tag, index) => (
            <button className="trend" key={tag}>
              <span>{tag}</span>
              <small>{[24, 18, 12][index]}k posts</small>
            </button>
          ))}
        </section>

        <section className="panel-block">
          <h2>People to follow</h2>
          {suggestions.map(([name, handle, initials]) => (
            <div className="suggestion" key={handle}>
              <div className="avatar compact">{initials}</div>
              <div>
                <strong>{name}</strong>
                <span>{handle}</span>
              </div>
              <button>Follow</button>
            </div>
          ))}
        </section>
      </aside>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
